package com.example.stopwatch

data class Lap(val lapNumber: Int, val lapTime: String)